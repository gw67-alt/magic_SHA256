#ifndef MAIN_H_
#define MAIN_H_

#include "connect.h"

void self_test(void * pvParameters);

#endif /* MAIN_H_ */
