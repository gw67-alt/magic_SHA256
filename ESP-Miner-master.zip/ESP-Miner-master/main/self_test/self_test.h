#ifndef SELF_TEST_H_
#define SELF_TEST_H_

void self_test(void * pvParameters);
bool should_test(GlobalState * GLOBAL_STATE);

#endif