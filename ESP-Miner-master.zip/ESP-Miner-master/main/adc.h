#ifndef ADC_H_
#define ADC_H_

void ADC_init(void);
uint16_t ADC_get_vcore(void);

#endif /* ADC_H_ */