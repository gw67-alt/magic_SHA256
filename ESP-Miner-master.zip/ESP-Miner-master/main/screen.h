#ifndef SCREEN_H_
#define SCREEN_H_

esp_err_t screen_start(void * pvParameters);
void screen_next(void);

#endif /* SCREEN_H_ */
