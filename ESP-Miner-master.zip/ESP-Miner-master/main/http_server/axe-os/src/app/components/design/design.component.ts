import { Component } from '@angular/core';

@Component({
  selector: 'app-design',
  templateUrl: './design.component.html',
})
export class DesignComponent {
  constructor() { }
}
