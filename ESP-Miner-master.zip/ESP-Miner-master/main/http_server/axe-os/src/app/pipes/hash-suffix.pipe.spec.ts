import { HashSuffixPipe } from './hash-suffix.pipe';

describe('HashSuffixPipe', () => {
  it('create an instance', () => {
    const pipe = new HashSuffixPipe();
    expect(pipe).toBeTruthy();
  });
});
