export interface ISystemStatistics {
    currentTimestamp: number;
    statistics: number[][];
}
