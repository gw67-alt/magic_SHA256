export enum eASICModel {
    BM1366 = 'BM1366',
    BM1368 = 'BM1368',
    BM1397 = 'BM1397',
    BM1370 = 'BM1370'
}
