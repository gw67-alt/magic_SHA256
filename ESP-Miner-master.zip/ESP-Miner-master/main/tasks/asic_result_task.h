#ifndef ASIC_result_TASK_H_
#define ASIC_result_TASK_H_

void ASIC_result_task(void *pvParameters);

#endif