#!/bin/bash

./merge_bin.sh -u $1
